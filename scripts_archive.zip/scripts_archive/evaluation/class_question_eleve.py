# -*- coding: utf-8 -*-
"""
Created on Fri Dec 17 13:05:20 2021

@author: xpess
"""

class Question_Eleve :
    """ Définition d'une question pour un élève"""
    def __init__(self):
        self.id_eleve = 0
        self.id_ds = 0
        self.id_ques = 0
        self.note = 0
        
